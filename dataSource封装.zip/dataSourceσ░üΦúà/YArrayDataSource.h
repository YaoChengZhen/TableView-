//
//  YArrayDataSource.h
//  SmallMethodVC
//
//  Created by BruceYao on 2017/10/18.
//  Copyright © 2017年 BruceYao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//block cell
//其中
typedef void(^TableViewCellBlock)(UITableViewCell *cell, id item, NSIndexPath *indexPath);

@interface YArrayDataSource : NSObject<UITableViewDataSource>

- (instancetype)initWithMutableSectionData:(NSArray<NSDictionary*>*)dataDict cellIdentifers:(NSArray <NSString*>*)identifers cellBlock:(TableViewCellBlock)cellBlock;

- (instancetype)initWithSingleSectionData:(NSArray *)dataDict cellIdentifer:(NSString *)identifer cellBlock:(TableViewCellBlock)cellBlock;
@end
