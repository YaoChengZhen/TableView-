//
//  YArrayDataSource.m
//  SmallMethodVC
//
//  Created by BruceYao on 2017/10/18.
//  Copyright © 2017年 BruceYao. All rights reserved.
//

#import "YArrayDataSource.h"
@interface YArrayDataSource()
//数据源:指的是section的个数:当为多个的时候，如果是一个section就只存放model
@property (nonatomic, copy) NSArray *dataArray;
//复用identifier
@property (nonatomic, copy) NSArray *identifiers;
//单个section
@property (nonatomic, copy) NSString *identifer;
//回调block
@property (nonatomic, copy) TableViewCellBlock cellBlock;
@end
@implementation YArrayDataSource

#pragma mark - 初始化
- (instancetype)initWithSingleSectionData:(NSArray *)dataArray cellIdentifer:(NSString *)identifer cellBlock:(TableViewCellBlock)cellBlock {
    self = [super init];
    if (self) {
        self.cellBlock = cellBlock;
        self.dataArray = dataArray;
        self.identifer = identifer;
        self.identifiers = nil;
    }
    return self;
}

- (instancetype)initWithMutableSectionData:(NSArray<NSDictionary *> *)dataArray cellIdentifers:(NSArray<NSString *> *)identifers cellBlock:(TableViewCellBlock)cellBlock {
    self = [super init];
    if (self) {
        self.cellBlock = cellBlock;
        self.dataArray = dataArray;
        self.identifer = nil;
        self.identifiers = identifers;
    }
    return self;
}

- (id)itemAtIndexPath:(NSIndexPath*)indexPath {
    if (self.identifiers == nil) {
        return self.dataArray[(NSUInteger)indexPath.row];
    } else {
        NSDictionary *sectionDic = self.dataArray[indexPath.section];
        NSArray *rowArray = sectionDic[@"values"];
        return rowArray[indexPath.row];
    }
}

#pragma mark - UITableViewDataSource
//section 数量
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.identifiers == nil) {
        return 1;
    }else {
        return self.dataArray.count;
    }
}
//每个section的 数目
- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.identifiers == nil) {
        return self.dataArray.count;
    }else {
        NSDictionary *sectionDic = self.dataArray[section];
        //    约定必须有两个key,第一是name,第二是：values:
        return [sectionDic[@"values"] count];
    }
}
- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    if (self.identifiers == nil) {
        cell = [tableView dequeueReusableCellWithIdentifier:self.identifer forIndexPath:indexPath];
    }else {
        for (NSInteger section = 0; section < self.identifiers.count; section++ ) {
            if (indexPath.section == section) {
                cell = [tableView dequeueReusableCellWithIdentifier:self.identifiers[section] forIndexPath:indexPath];
            }
        }
    }
    id item = [self itemAtIndexPath:indexPath];
    if (self.cellBlock) {
        self.cellBlock(cell, item, indexPath);
    }
    // 此步设置用于实现cell的frame缓存，可以让tableview滑动更加流畅
     [cell useCellFrameCacheWithIndexPath:indexPath tableView:tableView];
    return cell;
}
@end
